import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup = new FormGroup({});
  errorMessage: string = '';
  submitted: boolean = false;
  isBusy: boolean = false;
  constructor(private readonly loginService: LoginService, private readonly router: Router) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      userName: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required])
    });
  }

  hasError(name: string) {
    const control = this.loginForm.controls[name];
    return control && (control.touched || this.submitted) && control.errors && control.errors['required'];
  }
  
  login(isValid: boolean) {
    this.submitted = true;
    this.errorMessage = '';
    if (isValid) {
      this.isBusy = true;
      const formData = this.loginForm.value;
      this.loginService.login(formData.userName, formData.password).then(res => {
        if (res.loginSuccessful) {
          localStorage.setItem('userName', formData.userName);
          this.router.navigateByUrl('/dashboard');
        } else {
          this.errorMessage = 'Invalid user name or password';
        }
        this.isBusy = false;
      })
    }
  }



}
