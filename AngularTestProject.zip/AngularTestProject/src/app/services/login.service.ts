import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { ILoginResult } from '../models/ILoginResult';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  authStatusChnage: Subject<boolean> = new Subject();
  constructor() { }

  login(userName: string, password: string): Promise<ILoginResult> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const result: ILoginResult = { loginSuccessful: (/admin/ig.test(userName) && /password/ig.test(password)) }
        resolve(result);
      }, 1000)
    })
  }

  isLogedin(): boolean {
    return localStorage.getItem('userName') !=null
  }

  logout(): void {
    localStorage.clear();
    this.authStatusChnage.next(false);
  }
}
